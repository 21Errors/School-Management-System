
import java.io.Serializable;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class bean implements Serializable{
    protected String davince;
    protected String junkie;

    public bean() {
    }

    public String getDavince() {
        return davince;
    }

    public String getJunkie() {
        return junkie;
    }

    public void setDavince(String davince) {
        this.davince = davince;
    }

    public void setJunkie(String junkie) {
        this.junkie = junkie;
    }
    
    
    
}
