/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package schoolgui;

/**
 *
 * @author kamog
 */
import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public class Main {
    public static void main(String[] args) {
        String pattern = "Hello, {0}!"; // The pattern string with placeholders
        String name = "World"; // The value to substitute in the placeholder

        // Create a ResourceBundle for English
        ResourceBundle enBundle = ResourceBundle.getBundle("messages", Locale.ENGLISH);
        String enMessage = enBundle.getString("greeting");

        // Create a ResourceBundle for French
        ResourceBundle frBundle = ResourceBundle.getBundle("messages", Locale.FRENCH);
        String frMessage = frBundle.getString("greeting");

        // Format the messages using MessageFormat
        String enGreeting = MessageFormat.format(enMessage, name);
        String frGreeting = MessageFormat.format(frMessage, name);

        System.out.println("English: " + enGreeting);
        System.out.println("French: " + frGreeting);
    }
}
