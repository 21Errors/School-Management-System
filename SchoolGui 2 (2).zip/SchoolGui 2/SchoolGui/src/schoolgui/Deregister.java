package schoolgui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Deregister {
    // Connection details to your MySQL database
    private static final String URL = "jdbc:mysql://localhost:3306/school database, root, 7habO.72719)";
    private static final String USERNAME = "your_username";
    private static final String PASSWORD = "your_password";

    public static void deregisterStudentFromDatabase(String studentName) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            String sql = "DELETE FROM students WHERE name = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, studentName);
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println(studentName + " has been deregistered successfully.");
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
