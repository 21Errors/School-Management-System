package schoolgui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Timetable extends JFrame {
    private JTextField classTextField;
    private JTable table;

    public Timetable() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Timetable");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        // Panel for class input
        JPanel classPanel = new JPanel(new FlowLayout());
        JLabel classLabel = new JLabel("Enter Class Name:");
        classTextField = new JTextField(20);
        JButton viewButton = new JButton("View Timetable");
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayTimetable();
            }
        });
        classPanel.add(classLabel);
        classPanel.add(classTextField);
        classPanel.add(viewButton);
        add(classPanel, BorderLayout.NORTH);

        // Create a JTable
        table = new JTable();

        // Add the table to a JScrollPane for scrolling if needed
        JScrollPane scrollPane = new JScrollPane(table);

        // Add the JScrollPane to the frame
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    public void displayTimetable() {
        try {
            Connection conn = Connect.ConnecrDB();
            String className = classTextField.getText();
            String sql = "SELECT * FROM timetable WHERE ClassName=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, className);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Day");
            model.addColumn("Time");
            model.addColumn("Subject");
            model.addColumn("Teacher");

            while (rs.next()) {
                String day = rs.getString("day");
                String time = rs.getString("time");
                String subject = rs.getString("subject");
                String teacher = rs.getString("teacher");

                model.addRow(new Object[]{day, time, subject, teacher});
            }

            table.setModel(model);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error retrieving timetable: " + e.getMessage());
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Timetable().setVisible(true);
            }
        });
    }
}
