package schoolgui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeregisterStudents extends javax.swing.JFrame {

    public DeregisterStudents() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton(); // Back button

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14));
        jLabel1.setText("Enter Student ID:");

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14));
        jButton1.setText("Deregister");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // Back button
        jButton2.setText("Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(40, Short.MAX_VALUE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jButton1)
                                                .addGap(115, 115, 115))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jButton2) // Back button
                                                .addGap(127, 127, 127))))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel1)
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton2) // Back button
                                .addGap(33, 33, 33))
        );

        pack();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        String studentName = jTextField1.getText().trim();
        deregisterStudentFromDatabase(studentName);
    }

    private void deregisterStudentFromDatabase(String studentName) {
    // Connection details to your MySQL database
    String URL = "jdbc:mysql://localhost:3306/school";
    String USERNAME = "root";
    String PASSWORD = "7habO.72719";

    Connection connection = null;
    PreparedStatement deleteStatement = null;
    PreparedStatement insertStatement = null;

    try {
        connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        // Create a prepared statement to delete the student from the current table
        String deleteSql = "DELETE FROM students WHERE id = ?";
        deleteStatement = connection.prepareStatement(deleteSql);
        deleteStatement.setString(1, studentName);
        
        // Execute the delete operation
        int rowsDeleted = deleteStatement.executeUpdate();
        
        if (rowsDeleted > 0) {
            // If the deletion was successful, move the student record to the "previous_users" table
            String insertSql = "INSERT INTO previous_users SELECT * FROM students WHERE id = ?";
            insertStatement = connection.prepareStatement(insertSql);
            insertStatement.setString(1, studentName);
            int rowsInserted = insertStatement.executeUpdate();
            
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, studentName + " has been moved to the 'previous_users' table successfully.");
            } else {
                JOptionPane.showMessageDialog(null, "Error moving student to 'previous_users' table.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Student not found.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Close the resources
        try {
            if (deleteStatement != null) {
                deleteStatement.close();
            }
            if (insertStatement != null) {
                insertStatement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        // Implementing back button functionality to navigate back to the previous screen
        setVisible(false);
        // Assuming the previous screen is AdminMenu
       
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeregisterStudents().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2; // Back button
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
