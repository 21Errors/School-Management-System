/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package schoolgui;
/**
 *
 * @author user
 */
public class Accounts {
    protected String iDNumber;
    protected String firstName;
    protected String lastName;
    protected String age;
    protected String telephone;
    protected String password;
    protected String className;
    protected String gender;
    protected String address;

    public Accounts() {
    }

    public Accounts(String iDNumber, String firstName, String lastName, String age, String telephone, String password, String className, String gender, String address) {
        this.iDNumber = iDNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.telephone = telephone;
        this.password = password;
        this.className = className;
        this.gender = gender;
        this.address = address;
    }

    public String getiDNumber() {
        return iDNumber;
    }

    public void setiDNumber(String iDNumber) {
        this.iDNumber = iDNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Accounts{" + "iDNumber=" + iDNumber + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + ", telephone=" + telephone + ", password=" + password + ", className=" + className + ", gender=" + gender + ", address=" + address + '}';
    }

}