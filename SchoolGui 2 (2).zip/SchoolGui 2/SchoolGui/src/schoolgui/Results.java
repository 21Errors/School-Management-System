package schoolgui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class Results extends JFrame {
    private Connection conn;
    private JTable resultTable;

    public Results() {
        initComponents();
        conn = Connect.ConnecrDB();
        displayResults();
    }

    private void initComponents() {
        setTitle("Student Results");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());

        // Table to display results
        resultTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(resultTable);

        // Add table to the panel
        panel.add(scrollPane, BorderLayout.CENTER);

        add(panel);
    }

    private void displayResults() {
        try {
            String sql = "SELECT s.studentID, s.firstName, s.lastName, r.subject, r.grade " +
                    "FROM students s " +
                    "LEFT JOIN results r ON s.studentID = r.studentID";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Student ID");
            model.addColumn("First Name");
            model.addColumn("Last Name");
            model.addColumn("Subject");
            model.addColumn("Grade");

            while (rs.next()) {
                String studentID = rs.getString("studentID");
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                String subject = rs.getString("subject");
                String grade = rs.getString("grade");

                model.addRow(new Object[]{studentID, firstName, lastName, subject, grade});
            }

            resultTable.setModel(model);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error retrieving results: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Results().setVisible(true);
            }
        });
    }
}
