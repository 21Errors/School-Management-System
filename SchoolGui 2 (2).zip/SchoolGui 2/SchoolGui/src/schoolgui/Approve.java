package schoolgui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Approve extends JFrame {

    private JTable table;
    private Connection conn;

    public Approve() {
        initComponents();
        setTitle("Approve Students");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 400);
        setLocationRelativeTo(null);
        setVisible(true);
        conn = Connect.ConnecrDB();
        displayStudents();
    }

    private void initComponents() {
        JLabel background = new JLabel(new ImageIcon(getClass().getResource("/schoolgui/background.jpg")));

        JPanel contentPane = new JPanel();
        contentPane.setLayout(null); // Setting layout to absolute

        JScrollPane scrollPane = new JScrollPane();
        table = new JTable();
        JButton approveButton = new JButton("Approve");
        JButton declineButton = new JButton("Decline");
        JButton backButton = new JButton("Back");

        table.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID", "First Name", "Last Name", "Status"}
        ));
        scrollPane.setViewportView(table);
        scrollPane.setBounds(10, 10, 750, 200); // Adjusting position and size

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(approveButton);
        buttonPanel.add(declineButton);
        buttonPanel.add(backButton);
        buttonPanel.setBounds(10, 220, 750, 50); // Adjusting position and size

        contentPane.add(scrollPane);
        contentPane.add(buttonPanel);

        // Adding action listeners
        approveButton.addActionListener(new ApproveButtonHandler());
        declineButton.addActionListener(new DeclineButtonHandler());
        backButton.addActionListener(new BackButtonHandler());

        // Setting panel size and adding background
        contentPane.setSize(800, 400);
        background.setBounds(0, 0, 800, 400);
        contentPane.add(background);

        setContentPane(contentPane);
    }

    private void displayStudents() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear the table before displaying new data

        try {
            String sql = "SELECT * FROM Enrollments";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                String studentID = rs.getString("StudentID");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                String status = rs.getString("Status");

                model.addRow(new Object[]{studentID, firstName, lastName, status});
            }

            rs.close();
            pst.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error displaying students: " + e.getMessage());
        }
    }

    private class ApproveButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                // Get student ID from the selected row
                String studentID = (String) table.getValueAt(selectedRow, 0);

                // Update student status in the database (approve or decline)
                updateStudentStatus(studentID);
            }
        }

        private void updateStudentStatus(String studentID) {
            // Implement logic to update student status in the database
            try {
                String sql = "UPDATE enrollments SET Status = 'Approved' WHERE StudentID = ?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, studentID);
                int rowsAffected = pst.executeUpdate();
                pst.close();

                if (rowsAffected > 0) {
                    // Move approved student to a new table (e.g., enrolled_students)
                    moveStudentToEnrolledTable(studentID);

                    // Post announcement
                    

                    // Refresh the displayed students
                    displayStudents();
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to update student status.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating student status: " + ex.getMessage());
            }
        }

        private void moveStudentToEnrolledTable(String studentID) {
            // Implement logic to move approved student to a new table (e.g., enrolled_students)
            try {
                // Insert the approved student into the enrolled_students table
                String insertSql = "INSERT INTO students (StudentID, FirstName, LastName,Age,Gender,ClassName,Status,parentID,password) SELECT StudentID, FirstName, LastName,Age,Gender,ClassName,Status FROM Enrollments WHERE StudentID = ?";
                PreparedStatement insertPst = conn.prepareStatement(insertSql);
                insertPst.setString(1, studentID);
                int insertRowsAffected = insertPst.executeUpdate();
                insertPst.close();

                if (insertRowsAffected > 0) {
                    // Delete the student from the students table
                    String deleteSql = "DELETE FROM students WHERE StudentID = ?";
                    PreparedStatement deletePst = conn.prepareStatement(deleteSql);
                    deletePst.setString(1, studentID);
                    deletePst.executeUpdate();
                    deletePst.close();
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to move student to enrolled table.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error moving student to enrolled table: " + ex.getMessage());
            }
        }

        
    }

    private class DeclineButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                // Get student ID from the selected row
                String studentID = (String) table.getValueAt(selectedRow, 0);

                // Update student status in the database (decline)
                updateStudentStatus(studentID);
            }
        }

        private void updateStudentStatus(String studentID) {
            // Implement logic to update student status in the database
            try {
                String sql = "UPDATE Enrollments SET Status = 'Declined' WHERE StudentID = ?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, studentID);
                int rowsAffected = pst.executeUpdate();
                pst.close();

                if (rowsAffected > 0) {
                    // Refresh the displayed students
                    displayStudents();
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to update student status.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error updating student status: " + ex.getMessage());
            }
        }
    }

    private class BackButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            dispose(); // Close the current frame
            setVisible(false);
            AdminMenu ob = new AdminMenu();
            ob.setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Approve();
            }
        });
    }
}
