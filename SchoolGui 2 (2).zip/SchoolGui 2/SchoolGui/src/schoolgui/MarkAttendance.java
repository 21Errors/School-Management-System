package schoolgui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import schoolgui.Attendance;


public class MarkAttendance extends JFrame {

    private JTextField codeField;

    public MarkAttendance(String attendanceCode) {
        if (attendanceCode == null || attendanceCode.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No attendance code provided.");
        }

        initComponents(attendanceCode);
        setTitle("Mark Attendance");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initComponents(String attendanceCode) {
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Attendance Code:");
        codeField = new JTextField(15);
        JButton submitButton = new JButton("Submit");

        panel.add(label);
        panel.add(codeField);
        panel.add(submitButton);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String inputCode = codeField.getText();
                if (inputCode.equals(attendanceCode)) {
                    JOptionPane.showMessageDialog(null, "Attendance marked successfully!");
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid attendance code. Please try again.");
                }
            }
        });

        add(panel);
    }

    public static void main(String[] args) {
        // Sample generated attendance code
        String attendanceCode = Attendance.generateAttendanceCode();
        new MarkAttendance(attendanceCode);
    }
}

