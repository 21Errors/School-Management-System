package schoolgui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Attendance extends JFrame {

    private JTextField codeField;

    public Attendance() {
        initComponents();
        setTitle("Mark Attendance");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Attendance Code:");
        codeField = new JTextField(15);
        JButton generateAttendanceCodeButton = new JButton("Generate");

        panel.add(label);
        panel.add(codeField);
        panel.add(generateAttendanceCodeButton);

        generateAttendanceCodeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Generate the attendance code
                String attendanceCode = generateAttendanceCode();

                // Set the generated code in the text field
                codeField.setText(attendanceCode);
            }
        });

        add(panel);
    }

    // Method to generate a random attendance code
    public static String generateAttendanceCode() {
        // Define the characters that can be used in the code
        String characters = "0123456789";

        // Set the length of the code
        int codeLength = 5;

        // Create a StringBuilder to store the generated code
        StringBuilder code = new StringBuilder();

        // Create a Random object to generate random indices
        Random random = new Random();

        // Generate the code
        for (int i = 0; i < codeLength; i++) {
            // Get a random character from the characters string
            char randomChar = characters.charAt(random.nextInt(characters.length()));
            // Append the character to the code
            code.append(randomChar);
        }

        // Convert the StringBuilder to a String and return the code
        return code.toString();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Attendance();
            }
        });
    }
}
